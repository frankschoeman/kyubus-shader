Place files in the "RetroArch base\shaders\" folder
Then in retroach, open the Quickmenu (F1) > shaders > load > kyubus-crtguest.slangp
F1 again to resume