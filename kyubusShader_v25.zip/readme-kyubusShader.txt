Kyubus Shader is a collection of Reshade and RetroArch retro CRT presets using existing shaders such as CRT-Guest, CRT-Royale and CRT-Lottes. I do not take credit for creating these shaders, they are just included for convenience. The Look-Up-Texture (LUT) and preset settings are my work.

Preview video: https://youtu.be/1Uxh_mhg0Ag

These presets are mainly developed on a monitor resolution of 1440p. But presets for 1080p and 4k monitors are included.

#1 To use this you need Reshade, download the latest version here: https://reshade.me/
#2 Open the .exe and follow the instructions, after chosing the graphics API you can skip the remaining steps.
#3 Copy the contents of this zip file to the game or emulator's executable.

Reshade Hotkeys:
Home 			: Brings up the ReShade interface
` 				: Toggle the current preset
Alt Gr + . 	: Next preset
Alt Gr + , 	: Prevrious preset

To make the lower resolution shader display correctly RetroArch(or any emulator) integer scaling needs to be switched ON ( Settings>video>scaling). GaussianBlur, LumaSharpen and Deband(range) are probably the first parameters you might want to adjust depending on the resolution of the content and your preferences. I also recommend trying RetroArch shaders underneath such as "/xbr/super-xbr-fast.slangp"(Set Input and Output gamma to 1.0 in shader parameters) and "/cubic/catmull-rom-fast.slangp". In case those aren't available I suggest setting the preset to one where GaussianBlur is enabled.

Suggested apps to use Reshade with:
ShaderGlass - System wide desktop shading
MPC-BE - The only media player I know Reshade can be enabled with (dx9)
RetroArch - Emulation. Look up the WindowCast core for shading ANY application inside RetroArch! It is not a standard core included with the RetroArch installer at the momen of writing.