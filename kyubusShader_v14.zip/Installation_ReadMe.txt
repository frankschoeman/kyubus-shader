#1 To use this you need Reshade, download the latest version here: https://reshade.me/
#2 Open the .exe and follow the instructions, after chosing the graphics API you can skip the remaining steps.
#3 Copy the contents of this zip file to the game's executable.
#4 Done