#1 Place the files from the "RetroArch-native-shader" folder into the "RetroArch base\shaders\" folder
#2 Then in retroach, open the Quickmenu with F1 > shaders > load > kyubus-crtguest.slangp